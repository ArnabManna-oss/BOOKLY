function newList(){
    var details=document.getElementById("details");
    var box=document.getElementById("box");
    details.style.display= "none";
    box.style.display="flex";
  }
  function MyList(){
    var details=document.getElementById("details");
    var box=document.getElementById("box");
    details.style.display= "flex";
    box.style.display="none";
  }